# BandSite CopyDeck


## Biography


### The Bees Knees


#### About the Musicians

**“We push each other to be the best. It’s not uncommon for one of us to say ‘this needs to be better, back to the drawing board’”** - Bryan Teddy, lead vocalist of The Bees Knees

##### The Bees Knees

The Bees Knees is a pop rock band originating from San Francisco, California. The band consists of lead vocalist Bryan Teddy, guitarist Mack Tolkens, guitarist Andrew Green, bassist Kent Zulkee and drummer Freddie Fischer. The band achieved its first commercial success as an unsigned act, drawing attention from manager Cam Adams. Having worked with other popular acts (The Elephant In The Room, One Trick Pony, The Cat’s Meow), Adams was confident the band could succeed even further, pushing them to sign with Magenta Records. 

From there, the band has soared, gaining international recognition and ranking in the top 10 on the Poster Charts. New fans immediately fell in love with the band’s original and organic attitude, solidifying their place as one of the hottest and fastest up and coming acts of this century. Fans affectionately refer to themselves as “The Hive” and are drawn to their candid and authentic performances on stage. Looking forward to touring in the future, The Bees Knees are currently recording their second studio album, looking to be released in late 2021.


#### Photo Gallery


#### Join the Conversation


##### Name

_Enter your name_


##### Comment

_Add a new comment_


##### Connor Walton

02/17/2021

This is art. This is inexplicable magic expressed in the purest way, everything that makes up this majestic work deserves reverence. Let us appreciate this for what it is and what it contains.


##### Emilie Beach

01/09/2021

I feel blessed to have seen them in person. What a show! They were just perfection. If there was one day of my life I could relive, this would be it. What an incredible day.


##### Miles Acosta

12/20/2020

I can't stop listening. Every time I hear one of their songs - the vocals - it gives me goosebumps. Shivers straight down my spine. What a beautiful expression of creativity. Can't get enough.


#### Get In Touch


##### Cam Adams \
The Bees Knees Management

503 Broadway Penthouse,

New York, NY 10012, USA

info@thebeesknees.com


##### Pearl Gregg \
Limitless Artist Group

Booking Agent for

US / South America / Japan

pearl.gregg@limitlessag.com


##### Carson Whyte \
ARCH Entertainment

Booking Agent for

UK / EU / AU

cwhyte@archentertainment.com


###### Copyright The Bees Knees © 2021 All Rights Reserved


## 


## Shows


### Beautiful Beasts Album \
Queen of Yellow x For The Stings


#### Dates \
Venue \
Location

Mon Sept 06 2021 

Ronald Lane 

San Francisco, CA

Tue Sept 21 2021 

Pier 3 East 

San Francisco, CA 

Fri Oct 15 2021 

View Lounge 

San Francisco, CA 

Sat Nov 06 2021 

Hyatt Agency 

San Francisco, CA 

Fri Nov 26 2021

Moscow Center 

San Francisco, CA 

Wed Dec 15 2021 

Press Club 

San Francisco, CA

Buy Tickets